﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class buttonscript : MonoBehaviour {

     public void test()
    {
        SceneManager.LoadScene(2);
    }
}
